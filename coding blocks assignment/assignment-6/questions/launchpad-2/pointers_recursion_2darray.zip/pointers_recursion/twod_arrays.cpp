#include <iostream>
using namespace std;

void takeInput(int input[][4], int m) {
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < 4; j++) {
			cout << "Enter element in " << i << "th row and " << j << "th column" << endl;
			cin >> input[i][j];
		}
	}
}

void findNumber(int input[][4], int m, int tobefound) {
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < 4; j++) {
			if (input[i][j] == tobefound) {
				cout << "found the number at " << i << "th row and " << j << "th col\n";
				return;
			}
		}
	}
	cout << "couldnt find\n";
}

int main() {
	int input[4][4];

	takeInput(input, 4);

	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			cout << input[i][j] << " ";
		}
		cout << endl;
	}
	findNumber(input, 4, 15);
}

