#include <iostream>
using namespace std;

bool isSorted(int* array, int m) {
	if (m == 0 || m == 1) {
		return true;
	}	

	if (array[0] > array[1]) {
		return false;
	}

	bool isSmallerSorted = isSorted(array + 1, m-1);
	if (isSmallerSorted) 
		return true;
	else
		return false;
}

int index_of7(int* array, int size) {
	if (size == 0) {
		return -1;
	}
	if (array[0] == 7) {
		return 0;
	}
	
	int indexInSmallerArray = index_of7(array + 1, size - 1);
	if (indexInSmallerArray == -1) {
		return -1;
	} else {
		return indexInSmallerArray + 1;
	}
}
















int fib(int n) {
	if (n == 0) {
		return 0;
	}
	if (n == 1) {
		return 1;
	}
	return fib(n-1) + fib(n-2);
}

int factorial(int n) {
	if (n == 0) {
		return 1;
	}
	int smallerOutput = factorial(n - 1);
	return n * smallerOutput;
}

int main() {
	cout << factorial(10) << endl;
	cout << fib(10) << endl;
	int input[10] = {1,2,3,4,5,6,7,8,10,9};
	cout << isSorted(input, 10) << endl;
}

