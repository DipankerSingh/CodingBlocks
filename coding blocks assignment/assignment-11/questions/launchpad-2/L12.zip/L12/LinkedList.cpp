#include <iostream>
#include "Node.h"
using namespace std;

Node* takeInput() {
	int currentInput;
	cout << "Enter first element";
	cin >> currentInput;
	Node* head = NULL;
	Node* tail = NULL;

	while (currentInput != -1) {
		Node* newNode = new Node(currentInput);
		if (head == NULL) {
			head = newNode;
			tail = newNode;
		} else {
			/*
			Node* temp = head;
			while (temp->next != NULL) {
				temp = temp->next;
			}
			temp->next = newNode;
			*/
			tail->next = newNode;
			tail = newNode;
		}
		cout << "Enter next element\n";
		cin >> currentInput;
	}
	return head;
}

void printLL(Node* head) {
	while (head != NULL) {
		cout << head->data << "-->";
		head = head->next;
	}
	cout << endl;
}

Node* insert(Node* head, int position, int element) {
	Node* newNode = new Node(element);
	if (position == 0) {
		newNode->next = head;
		return newNode;
	}
	
	Node* temp = head;
	while (position != 1) {
		temp = temp->next;
		position--;
	}

	newNode->next = temp->next;
	temp->next = newNode;
	
	return head;
}

void test(Node* head) {
	delete head->next;
	head->next = NULL;
}

int main() {
	Node* head = takeInput();
	printLL(head);
	head = insert(head, 0, 1000);
	printLL(head);
	delete head;
}

