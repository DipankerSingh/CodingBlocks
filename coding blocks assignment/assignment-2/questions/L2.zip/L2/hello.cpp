// My Very First Program!
#include<iostream>
using namespace std;
int main() {
    int sum, a = 0;
    cout << 'A'+1 << '\n';
    cout << (5 && 4) << '\n';



    cout << "Hello World" <<'\n' << 3.14 <<'H';
    cout << "Welcome to coding blocks!";

    return 0;
}
