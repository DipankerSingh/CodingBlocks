// program to print the pattern
#include<iostream>
using namespace std;
int main() {
    int n;
    cin >> n;
    int i = 1, value = 1;
    while ( i <= n) {
        int j = 1;
        while (j <= i) {
            cout << value << ' ';
            value = value + 1;
            j = j + 1;
        }
        i = i + 1;
        cout << endl;
    }
    return 0;
}
