#include <iostream>
#include "TreeNode.h"
#include "Queue.h"
using namespace std;

TreeNode* takeLevelWiseInput() {
	cout << "Enter root data" << endl;
	int data;
	cin >> data;

	cout << "Enter number of children for " << data << endl;
	int num_children;
	cin >> num_children;

	TreeNode* root = new TreeNode(data, num_children);
	Queue<TreeNode*> q;
	q.enqueue(root);

	while (!q.is_empty()) {
		TreeNode* current_node = q.dequeue();
		int num_children = current_node->children_count;
		for (int i = 0; i < num_children; i++) {
			cout << "Enter " << i + 1 << "th child of ";
			cout << current_node->data << endl;
			int nextChildData;
			cin >> nextChildData;
			
			cout << "Enter child count for " << nextChildData << endl;
			int childNumChildren;
			cin >> childNumChildren;
			
			TreeNode* child = 
				new TreeNode(nextChildData, childNumChildren);
			current_node->children[i] = child;
			q.enqueue(child);
		}
	}
	return root;
}

void printTree(TreeNode* root) {
	cout << root->data << ":";
	for (int i = 0; i < root->children_count; i++){
		TreeNode* ithChild = root->children[i];
		cout << ithChild->data << ",";
	}
	cout << endl;

	for (int i = 0; i < root->children_count; i++){
		printTree(root->children[i]);
	}
}

TreeNode* takeTreeInput() {
	cout << "Enter root data" << endl;
	int data;
	cin >> data;

	cout << "Enter number of children for " << data << endl;
	int num_children;
	cin >> num_children;

	// Cant allocate on stack
	//TreeNode root(data, num_children);
	
	TreeNode* root = new TreeNode(data, num_children);
	for (int i = 0; i < num_children; i++) {
		TreeNode* nextChild = takeTreeInput();
		root->children[i] = nextChild;
	}
	return root;
}

void printAtK(TreeNode* root, int k) {
	if (k == 0) {
		cout << root->data << endl;
		return;
	}

	for (int i = 0; i < root->children_count; i++) {
		printAtK(root->children[i], k - 1);
	}
}

int max_data(TreeNode* root) {
	if (root == NULL) {
		return -1;
	}

	int max = root->data;
	for (int i = 0; i < root->children_count; i++) {
		int currentChildMax = max_data(root->children[i]);
		if (currentChildMax > max) {
			max = currentChildMax;
		}
	}
	return max;
}

int height(TreeNode* root) {
	if (root == NULL) {
		return 0;
	}
	int maxChildHeight = 0;
	for (int i = 0; i < root->children_count; i++) {
		int currenChildHeight = height(root->children[i]);
		if (currenChildHeight > maxChildHeight) {
			maxChildHeight = currenChildHeight;	
		}
	}
	return 1 + maxChildHeight;
}

int main() {
	//TreeNode* root = takeTreeInput();
	TreeNode* root = takeLevelWiseInput();
	printTree(root);
	cout << height(root);
	delete root;
}

