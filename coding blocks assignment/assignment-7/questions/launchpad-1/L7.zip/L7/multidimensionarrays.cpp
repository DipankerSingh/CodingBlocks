#include<iostream>
using namespace std;
void readMatrix(int mat[][3]) {

}
int main() {
    int mat[2][2][2] = { {{1,2}, {2,3}}, {{4,5},{5,6}}};
    int twoD[3][3] = {{1,2,3}, {3,4,5}, {5,6,7}};
    char strings[10][10];
    cin.getline(string[4],10);
    cout << twoD+1 << endl;
    cout << twoD[1] << endl;
    cout << twoD[0]+1 << endl;
    cout << &twoD[0][0] + 1 << endl;
    readMatrix(twoD);
    /*for(int i =0; i < 3; i++) {
        for(int j =0; j < 3; j++) {
            cin >> twoD[i][j];
        }
    }*/





}
