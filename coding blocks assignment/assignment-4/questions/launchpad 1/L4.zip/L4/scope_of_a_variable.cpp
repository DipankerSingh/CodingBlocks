#include<iostream>
using namespace std;
int main() {
//    int a = 10, b = 20, c = 5;
/*    while ( a< 30) {
        cout << c << endl;
        char c = 'A';
            cout << c << endl;
        a = a + 5;
    }*/
    for (int a = 10; a < 30; a++) {
//        int z  = 5;
        a = a + 2;
        cout << a << endl;
        a = 10;
        a = a + 5;
        cout << a << endl;
    }
    cout << a << endl;
/*    cout << a;
    cout << a << b << endl;
    cout << c << endl;*/
    return 0;
}
