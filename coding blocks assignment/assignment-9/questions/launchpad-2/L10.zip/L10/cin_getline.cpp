#include <iostream>
#include <cstring>
using namespace std;

int main() {
	char str[10];
	cin.getline(str, 10, ',');
	cout << strlen(str) << endl;
	for (int i = 0; str[i] != '\0'; i++) {
		cout << str[i] << endl;
	}
}
