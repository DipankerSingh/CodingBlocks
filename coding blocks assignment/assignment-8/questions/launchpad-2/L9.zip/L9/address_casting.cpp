#include <iostream>
using namespace std;

int main() {
 char a = 'a';
 int b = a;
 cout << b << endl;

 char * ap = &a;
 int * bp = (int *)ap;
 cout << bp << endl;
 cout << *bp << endl;

 int i = 97;
 void* vp = &i;
 vp = &b;

 int * ipp = (int*)vp;

 int* ip = &i;
 char* cp = (char*)ip;
 cout << cp << endl;
}
