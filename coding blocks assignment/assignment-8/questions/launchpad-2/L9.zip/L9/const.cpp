#include <iostream>
using namespace std;

int ii = 1000;

inline int max(int x, int y) {
	return (x > y)? x:y;
}

int findMax(int input[], int size, int beginIndex = 0 ) {

	if (beginIndex == size - 1) {
		return input[beginIndex];
	}

	int maxInSmallerArray = findMax(input, size, beginIndex + 1);
	return (maxInSmallerArray > input[beginIndex])?maxInSmallerArray:input[beginIndex];
}

int findMax(int input[]) {
	static int count = 0;
	count++;
	cout << count << endl;
	return 0;
}

int main() {
	int ii = 100;
	if (true) {
		int ii = 1003;
		cout << ii << endl;
	}
	cout << ii << endl;
	int array[] = {1,2,3,4,5,4,3,2,1};
	findMax(array);
	findMax(array);
	findMax(array);
	findMax(array);
	int const i = 10;
  int const * p = &i;
  int  j = 10;
	p = &j;
	cout << (*p);
	j++;
	cout << (*p);

	cout << "\n" <<  max(i, j) << endl;
//	int *p3 = &i;


	int i2 = 10;
	int * const p2 = &i2;
  int j2 = 111;
	//p2 = &j2;


	int const * const p4 = &i;
	//(*p4)++;
	//p4++;
}
