class stackq {
	Queue q1;
	Queue q2;

	int get_size() {

	}

	bool is_empty() {

	}

	int top() {

	}

	int pop() {

	}

	void push(int n) {
	}

};
